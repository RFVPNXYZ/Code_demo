import requests
import os
import pathlib
import re
import requests,os,sys,time
trang = "\033[1;37m"
xanh_la = "\033[0;32m"
xanh_duong = "\033[1;34m"
do = "\033[1;31m"
vang = "\033[1;33m"
tim = "\033[1;35m"
xanhnhat = "\033[0;36m"
lamd = "\033[1;34m"
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
vcl = "\033[0;33m"
pcm = "\033[0;32m"
#///////////////
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
              
         {xanh_la}TOOL LỌC URL
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
print(f' {do}* {pcmcute}Bạn Hãy Copy Từ Phần Điều Kiện Của Url')
print(f' {do}* {pcmcute}Để Tránh Lọc Nhầm Url Của Key Or Url Sp')
print(pcmcute+'='*50)
input_file = input(f'{vcl}File Lọc link: {pcmcute}')

with open(input_file, 'r') as file:
    content = file.read()

pattern = r'https?://[^\s/$.?#].[^\s]*'
matches = re.findall(pattern, content)

try:
    file_name = os.path.abspath(__file__)
    parent_dir = os.path.join(str(os.path.dirname(file_name)), 'decode')
    p = pathlib.Path(parent_dir)
    p.mkdir(parents=True, exist_ok=True)
    print(pcmcute+'='*50) 
    print('\033[1;32mTạo Thư Mục Thành Công \033[1;31m!!!')
except Exception as e:
    print('\033[1;37mĐã Có Thư Mục Trong Máy \033[1;31m!!!')

for url in matches:
    try:
        url_web = url.split("'")[0]
    except:
        url_web = url

    code = requests.get(url_web).text

    out_ = url_web.split('/')
    out = out_[len(out_) - 1].replace('.', '').replace('php', '').replace('html', '')

    output_file = os.path.join(parent_dir, f"{out}.py")
    with open(output_file, "w") as output:
        output.write(code)

    print(f"{xanh_la}Success {trang}=> {vcl}{url_web} And Save As {output_file}\n")

print(f'{xanh_la}ĐÃ LỌC LINK XONG')
