import os
import random
import threading
import requests
from pystyle import *
import time
import sys
import datetime
trang = "\033[1;37m"
xanh_la = "\033[0;32m"
xanh_duong = "\033[1;34m"
do = "\033[1;31m"
vang = "\033[1;33m"
tim = "\033[1;35m"
xanhnhat = "\033[0;36m"
lamd = "\033[1;34m"
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
cute = "\033[0;33m"
vcl = "\033[0;32m"
# Lmao
class MainSHare:
    def __init__(self):
        os.system("cls" if os.name == "nt" else "clear")
        try:
            logo=f"""
            
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
    {pcmcute}Anh Em Sử Dụng Tool Chế Độ 6.2 Để Ghét Token Pro5 Nhé {do}!!!
                        \n"""
                        
            print(logo)
            file_token=input(f"{pcmcute}Nhập FilT Chứa Token Pro5: {cute}")
            self.open_file = open(file_token).read().split('\n')
            self.open_file.remove('')
            self.total = str(len(self.open_file))
        except:
            quit(self._print(f"M-TOOL", 'Không Tìm Thấy File Bạn Đã Nhập ',file_token))
    def _print(self, symbol, text):
        return f"                      [{symbol}] {text}"
    def banner(self):
        os.system("cls" if os.name == "nt" else "clear")
        title = '\n\n'
        banner = f'''
        
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
          {luc}TOOL SHARE ẢO BẰNG TOKEN PRO5
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = =        
'''
        print(Center.XCenter(title+f'Token: {self.total}')+ Center.XCenter(banner)) 
        if self.total == '0':
            quit(self._print("M-TOOL", "Token Number Not Enough!"))
    def share(self, id_post, token):
        rq = random.choice([requests.get, requests.post])
        dt_now = datetime.datetime.now()
        response = rq(f'https://graph.facebook.com/me/feed?method=POST&link=https://m.facebook.com/{id_post}&published=0&access_token={token}').json()
        if 'id' in response:
            print(self._print(f"{xanhnhat}M-TOOL",f"{vcl}{response['id']}"))
        else:
            print(self._print(f"{xanhnhat}M-TOOL",f"{pcmcute}SHARE THẤT BẠI {do}!!!"))
    def run_share(self):
        while True:
            main.banner()
            try: 
                id_post = input(self._print(f"{xanhnhat}M-TOOL",f"{cute}Nhập Uid Bài Viết: {pcmcute}"))
                threa = int(input(self._print(f"{xanhnhat}M-TOOL",f"{cute}Nhập Luồng: {pcmcute}")))
                if id_post != '' and threa > 0:
                    break
                else:
                    print(self._print(f"{xanhnhat}M-TOOL", "\033[1;31mLuồng Phải Lớn Hơn 0 !"))
                    time.sleep(3)
            except:
                print(self._print(f"{xanhnhat}M-TOOL", "\033[1;31mTHREAD INT!"))
                time.sleep(3)
        while True:
            for token in self.open_file:
                t = threading.Thread(target=self.share, args=(id_post, token))
                t.start()
                while threading.active_count() > threa:
                    pass
if __name__ == "__main__":
    try:
        main = MainSHare()
        main.run_share()
    except KeyboardInterrupt:
        time.sleep(3)
        sys.exit('\n'+main._print(f'{xanhnhat}M-TOOL', '\033[1;32mGood Bye:)'))
