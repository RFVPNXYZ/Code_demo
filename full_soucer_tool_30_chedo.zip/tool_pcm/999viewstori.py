luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
vang = "\033[0;93m"
hong = "\033[1;35m"
xduong = "\033[1;34m"
trang = "\033[1;37m"
xanhnhat = "\033[1;36m"
xnhac = "\033[1;36m"
# Đánh Dấu Bản Quyền
ndp_tool = trang + "~" + trang + "[" + do + "+" + trang + "] " + trang + "=> "
ndp = trang + "~" + trang + "[" + do + "÷" + trang + "] " + trang + "=> "
# Config
__SHOP__ = 'Subre62.com'
__ZALO__ = '0834617174'
__ADMIN__ = 'Chí Mum'
__VERSION__ = '1.0'
# Phần List
list_id_name_page = []
count = 0
dem = 0
# import lib
import os,sys,requests,threading
from time import sleep
from datetime import datetime
from time import strftime
try:
    import requests
except:
    print(luc+"Bạn Chưa Tải Thư Viện \n Bắt Đầu Tải... ")
    os.system("pip install requests")
# ====================== [ FUNCTION ] ====================== 
def echo(a):

   for i in range(len(a)):

     sys.stdout.write(a[i])
     sys.stdout.flush()
     sleep(0.00130)
   print()
def banner():
    banner = f"""
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
 
          \033[1;33mTOOL BUFF STORY BẰNG PRO5
    \033[1;35m======================================== 
"""
    echo(banner)
def clear():
    os.system("cls" if os.name == "nt" else "clear")
def thanh():
    print('\033[0;37m============================================')
def ndp_delay(o):
    while(o>1):
        o=o-1
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][\033[1;37m.....\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][\033[1;37mX....\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][X\033[1;36mX\033[1;37m...\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][XX\033[1;32mX\033[1;37m..\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][XXX\033[1;35mX\033[1;37m.\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)
        print(f'\033[1;31m[\033[1;37mM\033[1;36m-\033[1;32mT\033[1;33mO\033[1;34mO\033[1;35mL\033[1;31m][XXXX\033[1;33mX\033[1;31m][\033[1;32m{o}\033[1;31m]','     ',end='\r');sleep(1/6)

def buffview(x, thanhphan9, url_str, cookie):
    time = datetime.now().strftime("%H:%M:%S")
    uid_page = list_id_name_page[x].split('|')[0]
    name_page = list_id_name_page[x].split('|')[1]
    list1 = (f'i_user={uid_page};')
    cookie9 = (f'{cookie}{list1}')
    headers = {
        'authority': 'www.facebook.com',
        'accept': '*/*',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'origin': 'https://www.facebook.com',
        'referer': url_str,
        'sec-ch-prefers-color-scheme': 'light',
        'sec-ch-ua': '"Chromium";v="106", "Google Chrome";v="106", "Not;A=Brand";v="99"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'empty',
        'sec-fetch-mode': 'cors',
        'sec-fetch-site': 'same-origin',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/106.0.0.0 Safari/537.36',
        'viewport-width': '1186',
        'x-fb-friendly-name': 'storiesUpdateSeenStateMutation',
        'x-fb-lsd': 'YCCQAywyZyd74odVp6QBrw',
        'cookie': cookie9,
    }

    data = {
        'av': uid_page,
        '__user': uid_page,
        'fb_dtsg': fb_dtsg,
        'jazoest': jazoest,
        'fb_api_caller_class': 'RelayModern',
        'fb_api_req_friendly_name': 'storiesUpdateSeenStateMutation',
        'variables': '{"input":{"bucket_id":"259253279258515","story_id":"'+str(thanhphan9)+'","actor_id":"'+uid_page+'","client_mutation_id":"1"},"scale":1}',
        'server_timestamps': 'true',
        'doc_id': '5127393270671537',
    }

    runview = requests.post('https://www.facebook.com/api/graphql/', headers=headers, data=data).json()
    print('\033[1;31m[\033[0;34m'+str(x+1)+'\033[1;31m] | \033[1;36m'+str(time)+' \033[1;31m| \033[0;32mSUCCESS \033[1;31m| \033[0;33m'+str(uid_page)+' \033[1;31m| \033[0;33m'+str(name_page)+'')# \033[1;31m| \033[0;34m'+str(thanhphan9)+'')
# =================[ START TOOL ]===========================

# VÀO GIAO DIỆN

clear()
banner()
cookie = input('\033[1;32mNhập Cookie Facebook Chứa Page Pro5: \033[1;37m')
headers = {
        'authority': 'mbasic.facebook.com',
        'cache-control': 'max-age=0',
        'sec-ch-ua': '"Google Chrome";v="93", " Not;A Brand";v="99", "Chromium";v="93"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'upgrade-insecure-requests': '1',
        'origin': 'https://mbasic.facebook.com',
        'content-type': 'application/x-www-form-urlencoded',
        'user-agent': 'Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/93.0.4577.82 Safari/537.36',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'sec-fetch-site': 'same-origin',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-user': '?1',
        'sec-fetch-dest': 'document',
        'referer': 'https://mbasic.facebook.com/',
        'accept-language': 'en-US,en;q=0.9',
        'cookie': cookie
}
    
try:
    print("\033[0;33mĐang Check Live Cookie...", end="\r")
    find_data = requests.get("https://mbasic.facebook.com/", headers=headers).text
    fb_dtsg = find_data.split('<input type="hidden" name="fb_dtsg" value="')[1].split('"')[0]
    jazoest = find_data.split('<input type="hidden" name="jazoest" value="')[1].split('"')[0]
except:
    exit("\033[1;37mCookie Die Kiểm Tra Lại \033[1;31m!!!")
clear()
banner()
# Get List UID + NAME Page Pro5
headers_getid = {
    'cookie': cookie, 
}
data = {
    'fb_dtsg': fb_dtsg,
    'jazoest': jazoest,
    'variables': '{"showUpdatedLaunchpointRedesign":true,"useAdminedPagesForActingAccount":false,"useNewPagesYouManage":true}',
    'doc_id': '5300338636681652'
}
getidpro5 = requests.post('https://www.facebook.com/api/graphql/', headers = headers_getid, data = data).json()['data']['viewer']['actor']['profile_switcher_eligible_profiles']['nodes']

for i in getidpro5:
    uid_page = i['profile']['id']
    name_page = i['profile']['name']
    gomlist = f'{uid_page}|{name_page}'
    list_id_name_page.append(gomlist)
# DỮ LIỆU ĐÃ GET + NHẬP DELAY + SỐ VIEW CẦN TĂNG!
print('\033[1;36mĐã Tìm Thấy '+trang+str(len(list_id_name_page))+xanhnhat+' Page Pro5')
thanh()
url_str = input('\033[1;32mNhập Link Str Cần Tăng View: '+trang)
# GET DỮ LIỆU TRONG URL
thanhphan9 = url_str.split('/')[5].split('/?')[0]
# NHẬP ĐÓ VIEW BẠN MUỐN TĂNG
thanh()
soluongview = int(input('\033[1;32mNhập Số View Muốn Tăng: \033[1;37m'))
thanh()
delay = int(input('\033[1;32mNhập Delay View: \033[1;37m'))
thanh()
# RUN CODE
for x in range(soluongview):
    dem=dem+1
    threading.Thread(target=buffview,args=(x, thanhphan9, url_str, cookie, )).start()
    ndp_delay(delay)