import requests,re
import os,sys
import time
import concurrent.futures
from requests import session
from colorama import Fore, Style
from pystyle import Write, Colors
from threading import Thread, Lock
import threading
from random import randint 
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
from pystyle import *
trang = "\033[1;37m"
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
xanhnhat = "\033[0;36m"

def run_check():
 os.system('clear')
 banner = f"""

    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝

        \033[1;93mTOOL LỌC MAIL BAO MÃ
{pcmcute}= = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
 """
 for x in banner:sys.stdout.write(x);sys.stdout.flush();time.sleep(0.00130)
 
 x = open(input("\033[0;34mNhập File Email Cần Lọc: \033[0;37m")).readlines()
 print(pcmcute+'='*50)
 save = input(f"\033[0;34mNhập File Lưu Email: {pcmcute}")
 print(pcmcute+'='*50)
 print("\033[0;33mVui Lòng Đợi Tool Check Mã")
 print (f"{pcmcute}Loading\033[0;31m...")
 time.sleep(2)
 print(pcmcute+'='*50)
 #os.system("clear")
 list = []
 for e in x:
  email = e.strip("\n")
  list.append(email)
 def run(email):
  headers1 = {'Host':'d.facebook.com','user-agent':'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.101 Mobile Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','x-requested-with':'mark.via.gp','dnt':'1','sec-fetch-site':'none','sec-fetch-mode':'navigate','sec-fetch-user':'?1','sec-fetch-dest':'document','accept-language':'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7'}
  get_ck = requests.get(url="https://d.facebook.com/",headers=headers1)
  cookie = get_ck.headers['set-cookie'].split('; sb=')[0]+';'+get_ck.headers['set-cookie'].split('sb=')[1].split(';')[0]+';'
  headers2 = {'Host':'d.facebook.com','cache-control':'max-age=0','upgrade-insecure-requests':'1','origin':'https://d.facebook.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.101 Mobile Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','x-requested-with':'mark.via.gp','sec-fetch-site':'same-origin','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://d.facebook.com/reg/?cid=103&refsrc=deprecated&_rdr','accept-language':'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7','cookie':cookie}
  get_data = requests.get(url="https://d.facebook.com/reg/?cid=103&refsrc=deprecated&_rdr",headers=headers2).text
  lsd = get_data.split('name="lsd" value="')[1].split('"')[0]
  jazoest = get_data.split('name="jazoest" value="')[1].split('"')[0]
  reg_impression_id = get_data.split('name="reg_impression_id" value="')[1].split('"')[0]
  reg_instance = get_data.split('name="reg_instance" value="')[1].split('"')[0]
  headers3 = {'Host':'d.facebook.com','cache-control':'max-age=0','upgrade-insecure-requests':'1','origin':'https://d.facebook.com','content-type':'application/x-www-form-urlencoded','user-agent':'Mozilla/5.0 (Linux; Android 10; M2006C3LG Build/QP1A.190711.020;) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/87.0.4280.101 Mobile Safari/537.36','accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9','x-requested-with':'mark.via.gp','sec-fetch-site':'same-origin','sec-fetch-user':'?1','sec-fetch-dest':'document','referer':'https://d.facebook.com/reg/?cid=103&refsrc=deprecated&_rdr','accept-language':'vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7','cookie':cookie}
  data = {'lsd':lsd,'jazoest':jazoest,'cpp':'2','reg_instance':reg_instance,'submission_request':'true','helper':'','reg_impression_id':reg_impression_id,'ns':'0','zero_header_af_client':'','app_id':'','logger_id':'','field_names[]':'firstname','field_names[]':'reg_email__','field_names[]':'sex','field_names[]':'birthday_wrapper','field_names[]':'reg_passwd__','lastname':'Nguyễn','firstname':'AnKhang','reg_email__':email,'sex':'2','custom_gender':'','did_use_age':'false','birthday_day':'1','birthday_month':'1','birthday_year':'1998','age_step_input':'','reg_passwd__':'','submit':'Đăng+ký'}
  check = requests.post("https://d.facebook.com/reg/submit/?cid=103", headers = headers3, data=data).text
  if f'{pcmcute}Nhập mật khẩu có tối thiểu 6 ký tự bao gồm số' in check:
   print ('\033[1;36mM\033[1;97m-\033[1;36mTOOL \033[0;37m| \033[0;33m' + email + " \033[0;37m| \033[0;32mBao Mã")
   open(save,"a").write(email + "\n")
  else:
   print ('\033[1;36mM\033[1;97m-\033[1;36mTOOL \033[0;37m| \033[0;34m' + email + " \033[0;37m| \033[0;31mKhông Bao Mã")

 with concurrent.futures.ThreadPoolExecutor() as executor:
  executor.map(run, list)
run_check()