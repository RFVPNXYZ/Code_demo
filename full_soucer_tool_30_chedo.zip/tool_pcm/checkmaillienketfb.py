import requests,re
import os,sys
import time
import concurrent.futures
from requests import session
from colorama import Fore, Style
from pystyle import Write, Colors
from threading import Thread, Lock
import threading
from random import randint 
from pystyle import Add, Center, Anime, Colors, Colorate, Write, System
from pystyle import *
trang = "\033[1;37m"
xanhnhat = "\033[1;36m"
pcmcute = "\033[0;37m"
def validfb():
  os.system('clear')
  logo=f"""
  
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
       \033[1;93mTOOL CHECK MAIL LIÊN KẾT FACEBOOK
{pcmcute}= = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
"""
  for v in logo:sys.stdout.write(v);sys.stdout.flush();time.sleep(0.00130)
  try:
    print ("\033[1;91m* \033[1;97mLƯU Ý:")
    print ("\033[1;91m• \033[1;97mHỖ TRỢ ĐỊNH DẠNG MAIL\033[1;91m|\033[1;97mPASS")
    print ("\033[1;91m• \033[1;97mTOOL CHẠY ĐA LUỒNG ĐỒNG NGHĨA VỚI IP CỦA BẠN SẼ DỄ BỊ FB BLOCK HƠN")
    print ("\033[1;91m• \033[1;97mVUI LÒNG FAKE IP TRƯỚC CHẠY TOOL NÀY")
    print ("\033[1;91m• \033[1;97mMỖI IP CHECK ĐƯỢC 50\033[1;91m-\033[1;97m80 MAIL RỒI ĐỔI IP KHÁC")
    print(pcmcute+'='*50)
    fileEmail = open(input(f"\033[0;33mNhập File Chứa Email\033[1;32m(\033[1;97mex\033[0;33m: \033[1;97mmail.txt\033[1;32m)\033[0;33m: {pcmcute}")).readlines()
    print(pcmcute+'='*50)
    valid = input(f"\033[0;33mNhập File Lưu Email Valid Facebook\033[1;32m(\033[1;97mex: mail1.txt\033[1;32m)\033[0;33m: {pcmcute}")
    print(pcmcute+'='*50)
  except:
    print (" \033[0;37mKHÔNG TÌM THẤY FILE BẠN ĐÃ NHẬP \033[0;31m!!!")
    quit()
    
    
    
  list_email_fb = []
  for line_email_fb in fileEmail:
    email_fb1 = line_email_fb.strip("\n")
    email_fb = email_fb1.split(':')[0]
    
    list_email_fb.append(email_fb)
  link1='https://m.facebook.com/login/identify/?ctx=recover&c=%2Flogin%2F&search_attempts=1&ars=facebook_login&alternate_search=1&show_friend_search_filtered_list=0&birth_month_search=0&city_search=0'
  h1={
          'Accept': '*/*',
          'Pragma': 'no-cache',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko',
  }
          
  ses=requests.Session()
  get_data=ses.get(link1,headers=h1)
  cookie=get_data.cookies.get_dict()['datr']
  get_data = get_data.text
  lsd=get_data.split('"lsd" value="')[1].split('"')[0]
  jazoest=get_data.split('"jazoest" value="')[1].split('"')[0]
  def run_check_valid(emailfb):
    data = f'lsd={lsd}&jazoest={jazoest}&email={emailfb}&did_submit=Rechercher'
          
    link2='https://m.facebook.com/login/identify/?ctx=recover&c=%2Flogin%2F&search_attempts=1&alternate_search=1&show_friend_search_filtered_list=0&birth_month_search=0&city_search=0'
          
    h2={
              'Accept': 'image/jpeg, application/x-ms-application, image/gif, application/xaml+xml, image/pjpeg, application/x-ms-xbap, */*',
              'Referer': 'https://m.facebook.com/login/identify/?ctx=recover&search_attempts=2&ars=facebook_login&alternate_search=0&toggle_search_mode=1',
              'Accept-Language': 'fr-FR,fr;q=0.8,ar-DZ;q=0.5,ar;q=0.3',
              'Content-Type': 'application/x-www-form-urlencoded',
              'User-Agent': 'Mozilla/4.0 (compatible; MSIE 7.0; Windows NT 6.2; WOW64; Trident/7.0; .NET4.0E; .NET4.0C; .NET CLR 3.5.30729; .NET CLR 2.0.50727; .NET CLR 3.0.30729',
              'Host': 'm.facebook.com',
              'Connection': 'Keep-Alive',
              'Cache-Control': 'no-cache',
              'Cookie':f'datr={cookie}',
              'Content-Length': '84',
  }
          
    check = requests.post(link2,headers=h2,data=data).text
    #cc = check.split('Votre recherche ne donne aucun résultat')
    kq_check = re.search("Votre recherche ne donne aucun résultat", check)
    n1=0
    n1+=1
    n2=0
    n2 +=1
    if kq_check == None:
      print (f'\033[0;34m{emailfb} \033[0;97m| \033[0;32mCó Liên Kết')
      time.sleep(2)
      open(valid,"a").write(emailfb+"\n")
    else:
      print (f'\033[0;34m{emailfb} \033[0;97m| \033[0;31mKhông Liên Kết')
      time.sleep(2)
  with concurrent.futures.ThreadPoolExecutor() as executor:
    executor.map(run_check_valid, list_email_fb)
validfb()