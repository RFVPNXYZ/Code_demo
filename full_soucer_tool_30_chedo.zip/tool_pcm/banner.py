import requests,os,sys,time
trang = "\033[1;37m"
xanh_la = "\033[0;32m"
xanh_duong = "\033[1;34m"
do = "\033[1;31m"
vang = "\033[1;33m"
tim = "\033[1;35m"
xanhnhat = "\033[1;36m"
lamd = "\033[1;34m"
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
#11 = "\033[1;35m"
#Lmao
thanh_xau=trang+'~'+do+'['+vang+'⟨⟩'+do+'] '+trang+'➩  '+xanhnhat
thanh_dep=trang+'~'+do+'['+xanh_la+'✓'+do+'] '+trang+'➩  '+xanhnhat
ip = requests.get("https://api.ipgeolocation.io/getip").json()
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
{tim}███╗   ██╗ ██████╗       ██╗  ██╗███████╗██╗   ██╗
{trang}████╗  ██║██╔═══██╗      ██║ ██╔╝██╔════╝╚██╗ ██╔╝
{tim}██╔██╗ ██║██║   ██║{trang}█{tim}█{trang}█{tim}█{trang}█{tim}╗█████╔╝ █████╗   ╚████╔╝ 
{trang}██║╚██╗██║██║   ██║╚════╝██╔═██╗ ██╔══╝    ╚██╔╝  
{tim}██║ ╚████║╚██████╔╝      ██║  ██╗███████╗   ██║   
{trang}╚═╝  ╚═══╝ ╚═════╝       ╚═╝  ╚═╝╚══════╝   ╚═╝   

\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = =
\033[1;31m* \033[1;37mTOOL ĐÃ ĐƯỢC \033[1;33mADMIN\033[1;31m: \033[1;32mCHÍ MUM \033[1;37mCẮT KEY
\033[1;31m➩ \033[1;97mTOOL 30 CHẾ ĐỘ NOKEY NÊN ANH EM CỨ SỬ DỤNG THOẢI MÁI KHÔNG CẦN VƯỢT LINK LẤY KEY MỖI NGÀY NHÉ
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = =
        '''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
from datetime import datetime
time = datetime.now().strftime("%H:%M:%S")
print(f"""{xanhnhat}┏━━━━━━━━━━━━━━━━━━━━━━━┓
        {xanhnhat}┃   {vang}THÔNG TIN CỦA BẠN   {trang}┃
        {trang}┗━━━━━━━━━━━━━━━━━━━━━━━┛ """)
print(f"\033[0;33mip của bạn là: \033[0;34m{ip['ip']}")
print("\033[0;33mVào Tool Lúc : \033[0;34m"+str(time)+" \033[0;32mChúc Bạn Chạy Tool Vui Vẻ")
print(pcmcute+'='*50) 
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{tim}┃   {vang}Tool Golike         {do}┃
{do}┗━━━━━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'0'+do+'] '+xanhnhat+'Tool Golike Tik Tok')
print(pcmcute+'='*50)
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{tim}┃   {vang}Tool Trao Đổi Sub   {do}┃
{do}┗━━━━━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'1'+do+'] '+xanhnhat+'Tool TDS Cookie Fb')
print('\033[1;37m>>> '+do+'['+vang+'1.1'+do+'] '+xanhnhat+'Tool TDS Pro5 Đa Luồng Full Job')
print('\033[1;37m>>> '+do+'['+vang+'1.2'+do+'] '+xanhnhat+'Tool TDS Tik Tok')
print(pcmcute+'='*50) 
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━━━━━┓
{tim}┃   {vang}Tool Tương Tác Chéo {do}┃
{do}┗━━━━━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'1.5'+do+'] '+xanhnhat+'Tool Tcc pro5')
print(pcmcute+'='*50) 
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━┓
{tim}┃   {vang}Tool Facbook   {do} ┃
{do}┗━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'3'+do+'] '+xanhnhat+'Tool Reg Pro5 \033[1;31m+ \033[0;36mÚp Avt Đa Luồng')
print('\033[1;37m>>> '+do+'['+vang+'4'+do+'] '+xanhnhat+'Tool Kích Hoạt Page Pro5 Bị Ẩn')
print('\033[1;37m>>> '+do+'['+vang+'5'+do+'] '+xanhnhat+'Tool Share Ảo Pro5 '+do+'['+vang+'Max Speed'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'6'+do+'] '+xanhnhat+'Tool Tăng View Story Bằng Pro5')
print('\033[1;37m>>> '+do+'['+vang+'7'+do+'] '+xanhnhat+'Tool Buff Menber Bằng pro5')
print('\033[1;37m>>> '+do+'['+vang+'8'+do+'] '+xanhnhat+'Tool Chuyển Quyền Admin Pro5 \033[1;31m+ \033[0;36mChấp Nhận')
print('\033[1;37m>>> '+do+'['+vang+'9'+do+'] '+xanhnhat+'Tool Buff Follow Fb Bằng Pro5')
print('\033[1;37m>>> '+do+'['+vang+'6.2'+do+'] '+xanhnhat+'Tool Gét Token Profile \033[1;31m+ \033[0;36mPro5 ')
print('\033[1;37m>>> '+do+'['+vang+'10'+do+'] '+xanhnhat+'Tool Spam messager')
print('\033[1;37m>>> '+do+'['+vang+'6.1'+do+'] '+xanhnhat+'Tool Tăng Cảm Xúc Story Bằng Pro5')
print('\033[1;37m>>> '+do+'['+vang+'9.1'+do+'] '+xanhnhat+'Tool Buff Comment Bằng Pro5')
print('\033[1;37m>>> '+do+'['+vang+'3.1'+do+'] '+xanhnhat+'Tool Reg Page Vị Trí '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'5.1'+do+'] '+xanhnhat+'Tool Share Ảo Bằng Token Pro5 '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'6.3'+do+'] '+xanhnhat+'Tool Gét Cookie Pro5 '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'6.4'+do+'] '+xanhnhat+'Tool Gét Token Facebook Dạng'+trang+' EAAB '+do+'['+vang+'Mới'+do+']')
print(pcmcute+'='*50)
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━┓
{tim}┃  {vang}Tool Tiện Ích   {do} ┃
{do}┗━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'10.3'+do+'] '+xanhnhat+'Tool Đào Mail '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'10.1'+do+'] '+xanhnhat+'Tool Tăng View '+do+'['+vang+'Hay Lỗi Nên Đừng Hỏi'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'12'+do+'] '+xanhnhat+'Tool Check Prox Siêu Víp')
print('\033[1;37m>>> '+do+'['+vang+'10.2'+do+'] '+xanhnhat+'Tool Lọc Mail Bao Mã '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'12.1'+do+'] '+xanhnhat+'Tool Đào Proxy Víp')
print('\033[1;37m>>> '+do+'['+vang+'11.1'+do+'] '+xanhnhat+'Tool Spam Sms \033[1;31m+ \033[0;36mCall '+do+'['+vang+'V3'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'15'+do+'] '+xanhnhat+'Tool Check Mail Liên Kết Fb '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'16'+do+'] '+xanhnhat+'Tool Buff Tym Tik Tok '+do+'['+vang+'Hay Lỗi Nên Đừng Hỏi'+do+']')
print(pcmcute+'='*50)
print(f"""{tim}┏━━━━━━━━━━━━━━━━━━━┓
{tim}┃  {vang}Tool Lọc Url    {do} ┃
{do}┗━━━━━━━━━━━━━━━━━━━┛ """)
print('\033[1;37m>>> '+do+'['+vang+'17'+do+'] '+xanhnhat+'Tool Lấy Code Từ Url '+do+'['+vang+'Mới'+do+']')
print('\033[1;37m>>> '+do+'['+vang+'18'+do+'] '+xanhnhat+'Tool Lọc Url '+do+'['+vang+'Mới'+do+']')
print(pcmcute+'='*50) 
menu_tool = input(thanh_dep+'Nhập Lựa Chọn'+trang+': '+vang)
if menu_tool=='1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999tdscokie.php').text
elif menu_tool=='1.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999tdspr5.php').text
elif menu_tool=='1.2':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999tdstiktok.php').text
elif menu_tool=='10.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999zefoi.php').text
elif menu_tool=='3':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999regpr5.php').text
elif menu_tool=='3.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999regpagevt.php').text
elif menu_tool=='4':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999kichpr5.php').text
elif menu_tool=='5':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999aopr5.php').text
elif menu_tool=='5.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999shareaotokenpro5.php').text    
elif menu_tool=='6':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999viewstori.php').text
elif menu_tool=='6.2':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999gettokenpro5.php').text
elif menu_tool=='6.3':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999getcookiepro5.php').text
elif menu_tool=='6.4':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999gettokenfb.php').text
elif menu_tool=='7':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999menbergrouppr5.php').text
elif menu_tool=='8':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999chuyenpr5.php').text
elif menu_tool=='9':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999buffflowpr5.php').text
elif menu_tool=='10':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999message.php').text
elif menu_tool=='12':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999checkproxi.php').text

elif menu_tool=='0':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999goliketok.php').text
elif menu_tool=='1.5':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999ttcp5.php').text
elif menu_tool=='6.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999camxucstory.php').text
elif menu_tool=='11.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999smscall.php').text
elif menu_tool=='9.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999cmtpro5.php').text
elif menu_tool=='12.1':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999daoproxy.php').text
elif menu_tool=='15':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/checkmaillienketfb.php').text
elif menu_tool=='10.2':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/locmailbaoma.php').text
elif menu_tool=='10.3':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999daomail.php').text
elif menu_tool=='16':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999timtik.php').text
elif menu_tool=='17':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999laycodeurl.php').text
elif menu_tool=='18':
    run_server=requests.post('http://chimumlikevip.xyz/999code_tool_python@@@/999locurl.php').text
exec(run_server)