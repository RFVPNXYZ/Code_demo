try:import requests,threading
except:import os;os.system('pip install requests')
from datetime import datetime
import requests,random,os,sys
from time import sleep,strftime
import requests,os,sys,time
xanhnhat = "\033[1;36m"
trang = "\033[1;37m"
pcmcute = "\033[0;37m"
hazz = "\033[0;33m"

def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
          \033[1;32mTOOL REG PGAE VỊ TRÍ MAX SPEED
\033[0;37m= = = = = = = = = = = = = = = = = = = = = = = = =
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00130)


def run():
    global list_token_page,s
    token_page=list_token_page[0]
    id_page=list_id_page[0]
    latitude=random.randrange(9999)
    longitude=random.randrange(3333)
    store_number=random.randrange(999)
    name=requests.get('https://story-shack-cdn-v2.glitch.me/generators/vietnamese-name-generator/female?count=2').json()['data'][0]['name']
    register=requests.post(f'https://graph.facebook.com/v12.0/{id_page}/locations?access_token={token_page}',data={'_reqName': 'object:page/locations','_reqSrc': 'LocationManagerUtils','always_open': 'false','differently_open_offerings': '{}','id': id_page,'ignore_warnings': 'true','is_franchise': 'false','locale': 'vi_VN','location': '{"city_id":2599270,"latitude":"21.'+str(latitude)+'","longitude":"105.2'+str(longitude)+'","street":"'+name+'","zip":"10000"}','method': 'post','permanently_closed': 'false','phone': '+84395581887','pickup_options': '[]','place_topics': '["123377808095874","530553733821238"]','pretty': '0','price_range': 'Unspecified','store_name': name,'store_number': store_number,'suppress_http_code': '1'}).json()
    if 'id' in register:
        s+=1
        id_register=register['id']
        time=datetime.now().strftime("%H:%M:%S")
        if choice=='':
            print(id_register)
            tach=requests.post(f'https://graph.facebook.com/v12.0/{id_page}/locations?access_token={token_page}',data={'_reqName': 'object:page/locations','_reqSrc': 'LocationManagerUtils','locale': 'vi_VN','location_page_id': id_register,'method': 'delete','pretty': '0','store_number': store_number,'suppress_http_code': '1'}).json()
            if 'success' in tach:
                print(f'[{s}][SUCCESSFULY REGISTRATION + DELETED][{time}][{name.upper()}][{id_register}]')
        else:print(id_register)
       
    elif 'error' in register:print(register['error']['message']);
    else:print(register);
    
def do_long(thread_step):
    for i in range(thread_step,luong):
        run()
list_token_page=[]
list_id_page=[]
token_s=1
banner()
print('\033[1;31m* \033[0;37mAnh Em Dùng Tool Chế Độ 6.4 Để Gét Token Nhé')
print('\033[1;97m[\033[1;34mNếu Không Nhập Nữa Thì Hãy Enter\033[1;97m]')
print(pcmcute+'='*50)
while(True):
    token_fb=input(f'\033[0;32mNHẬP TOKEN FACEBOOK \033[1;97m{token_s}\033[0;32m: \033[0;34m')
    print(pcmcute+'='*50)
    if token_fb=='' and len(list_token_page)>0:break
    id_page=input(f'\033[0;32mNHẬP ID PAGE MẸ \033[1;97m{token_s}\033[0;32m: \033[0;34m')
    print(pcmcute+'='*50)
    get_token_page=requests.get(f'https://graph.facebook.com/{id_page}?fields=access_token&access_token={token_fb}').json()
    if 'access_token' in get_token_page:
        token_page=get_token_page['access_token']
        list_token_page.append(token_page)
        list_id_page.append(id_page)
        token_s=token_s+1
    elif 'error' in get_token_page:print(get_token_page['error']['message'])
    else:print(get_token_page)
print("\033[1;97m[\033[1;34mENTER \033[1;97m- \033[1;34mTỰ TÁCH\033[1;97m]   [\033[1;34mNHẬP BẤT KÌ \033[1;97m- \033[1;34mKHÔNG TỰ TÁCH\033[1;97m]")
print(pcmcute+'='*50)
choice=input('\033[0;32mNHẬP LỰA CHỌN: \033[0;34m')
print(pcmcute+'='*50+hazz)
luong=100
s=0
while(True):
    threads = []
    for i in range(luong):
        threads += [threading.Thread(target = do_long,args=(i,))]
    for i in range(luong):
        threads[i].start()
    for i in range(luong):
        threads[i].join()