import requests,os,sys,time
from time import sleep
#from datetime import timezone, datetime, timedelta
luc = "\033[1;32m"
trang = "\033[1;37m"
do = "\033[1;31m"
xanhnhat='\033[1;36m'
pcm='\033[0;37m'
vang = "\033[1;33m"
timnho='\033[0;34m'
vangnho='\033[0;33m'
donho='\033[0;31m'
xanhla='\033[0;32m'
tranglon='\033[1;97m'
def logo():
    os.system("cls" if os.name == "nt" else "clear")
    logo=f"""

    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝

        {vang}TOOL BUUF COMMENT BẰNG PRO5
{pcm}= = = = = = = = = = = = = = = = = = = = = = = = = = =
  """
    for i in logo:
        sys.stdout.write(i)
        sys.stdout.flush()
        time.sleep(0.00100)
logo()
ck_fb= input(f"{timnho}Nhập Cookie Chứa Page Pro5: {pcm}")
print(pcm+'='*50)
print(f"{vangnho}Đang Get Token{trang}...",end='\r')


hed_gettoken = {
    'authority': 'www.instagram.com',
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
    'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
    'cache-control': 'no-cache',
    'cookie': ck_fb,
    'pragma': 'no-cache',
    'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.115 Safari/537.36',
}
try:
    token_fb = requests.get('https://www.facebook.com/dialog/oauth?client_id=124024574287414&redirect_uri=https://www.instagram.com/accounts/signup/&&scope=email&response_type=token', headers=hed_gettoken).url.split('#access_token=')[1].split('&data_access_expiration_time')[0]
except:
    print(f'{pcm}Get Token Thất Bại, Hãy Xem Lại Cookie {donho}!!!')
    sleep(3)
    quit()

header={
    'cookie': ck_fb,
}

def Start():
    get_ = requests.get('https://graph.facebook.com/me/accounts?access_token='+token_fb).json()['data']
    for access in get_:
        tok = access['access_token']
        uid_page=access['id']
        name=access['name']
        try:
            url = f"https://graph.facebook.com/{id_post}/comments?method=post&access_token={tok}&message={noidung}"
            r = requests.post(url)
            a=r.text
            if ['id'] in r:
                print(f'{xanhnhat}M{trang}-{xanhnhat}TOOL {donho}| {pcm}Uid: {vangnho}{uid_page} {donho}| {pcm}Name: {vangnho}{name} {donho}| {pcm}Commet Port: {vangnho}{id_post} {donho}| {trang}Thất Bại')
            #print(['id'])
            else:
                print(f'{xanhnhat}M{trang}-{xanhnhat}TOOL {donho}| {pcm}Uid: {vangnho}{uid_page} {donho}| {pcm}Name: {vangnho}{name} {donho}| {pcm}Commet Port: {vangnho}{id_post} {donho}| {xanhla}Thành Công')
        except:
            print(f"{pcm}Thất Bại {donho}!!!")
def Start1():
    get_ = requests.get('https://graph.facebook.com/me/accounts?access_token='+token_fb).json()['data']
    for access in get_:
        tok = access['access_token']
        uid_page=access['id']
        name=access['name']
        try:
            url = f"https://graph.facebook.com/{id_post}/comments?method=post&access_token={tok}&message={noidung} @[{id_bb}:0]"
            r = requests.post(url)
            a=r.text
            if ['id'] in r:
                print(f'{xanhnhat}M{trang}-{xanhnhat}TOOL {donho}| {pcm}Uid: {vangnho}{uid_page} {donho}| {pcm}Name: {vangnho}{name} {donho}| {pcm}Commet Port: {vangnho}{id_post} {donho}| {trang}Thất Bại')
            #print(['id'])
            else:
                print(f'{xanhnhat}M{trang}-{xanhnhat}TOOL {donho}| {pcm}Uid: {vangnho}{uid_page} {donho}| {pcm}Name: {vangnho}{name} {donho}| {pcm}Commet Port: {vangnho}{id_post} {donho}| {xanhla}Thành Công')
        except:
            print(f"{pcm}Thất Bại {donho}!!!")

chon=input(f"{tranglon}Bạn Có Muốn Comment Tag Id Bạn Bè Không {luc}({tranglon}Y{do}/{tranglon}n{luc}){tranglon}: {pcm}")
if chon == 'N' or chon == 'n':
    id_post=input(f"{timnho}Nhập Id Post: {pcm}")
    noidung=input(f"{timnho}Nhập Nội Dung: {pcm}")
    print(pcm+'='*50)
    Start()
else:
    id_post=input(f"{timnho}Nhập Id Post: {pcm}")
    noidung=input(f"{timnho}Nhập Nội Dung: {pcm}")
    id_bb=input(f"{timnho}Nhập Id Bạn Bè Cần Tag: {pcm}")
    print(pcm+'='*50)
    Start1()