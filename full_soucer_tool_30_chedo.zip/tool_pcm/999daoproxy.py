import requests,os,sys,time
import random
xanhnhat = "\033[1;36m"
trang = "\033[1;37m"
pcmcute = "\033[0;37m"
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
              \033[1;32mTOOL ĐÀO PROXY 
\033[0;37m= = = = = = = = = = = = = = = = = = = = = = = = =
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00130)
banner()
def generate_proxy():
    ip = f"{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(0, 255)}"
    port = random.randint(100000, 655535)
    return f"{ip}:{port}"

def main():
    try:
        num_proxies = int(input("\033[0;34mNhập số lượng proxy\033[0;37m: \033[0;33m"))
        print(pcmcute+'='*50)
        proxies = [generate_proxy() for _ in range(num_proxies)]
        with open("proxies.txt", "w") as file:
            for proxy in proxies:
                file.write(proxy + "\n")
        #print(pcmcute+'='*50)
        print(f"\033[1;32mĐã Đào Xong \033[1;97m{num_proxies} \033[1;32mproxies đã được lưu tại file\033[1;37m: \033[1;97mproxies.txt")
        print(pcmcute+'='*50)
    except ValueError:
       print(pcmcute+'='*50)
       print("\033[0;37mNhập số không hợp lệ \033[0;31m!!!")
       print(pcmcute+'='*50)

if __name__ == "__main__":
    main()
    