from time import sleep
import os
import json
import threading
import requests,os,sys,time
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
trang = "\033[1;37m"
xanhnhat = "\033[1;36m"
vcl = "\033[0;33m"
do = "\033[1;31m"
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
      {luc}TOOL GÉT TOKEN FACEBOOK DẠNG {do}EAAB
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = = = = = =  
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
#os.system('clear')
ck_fb=input(f'{vcl}Nhập Cookie Facebook: {pcmcute}')
print(pcmcute+'='*50) 
print(f"{xanhnhat}Đang Gét Token{do}...")
print(pcmcute+'='*50) 
hed_gettoken = {
        'authority': 'www.instagram.com',
        'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
        'accept-language': 'vi-VN,vi;q=0.9,fr-FR;q=0.8,fr;q=0.7,en-US;q=0.6,en;q=0.5',
        'cache-control': 'no-cache',
        'cookie': ck_fb,
        'pragma': 'no-cache',
        'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="102", "Google Chrome";v="102"',
        'sec-ch-ua-mobile': '?0',
        'sec-ch-ua-platform': '"Windows"',
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.115 Safari/537.36',
}
try:
    token_fb = requests.get('https://www.facebook.com/dialog/oauth?client_id=124024574287414&redirect_uri=https://www.instagram.com/accounts/signup/&&scope=email&response_type=token', headers=hed_gettoken).url.split('#access_token=')[1].split('&data_access_expiration_time')[0]
    print(f'{luc}Get Token Thành Công:{pcmcute} {token_fb}')
except:
    print(f'{do}Get Token Thất Bại, Hãy Xem Lại Cookie')
    #print(token_fb)
    sleep(3)
    quit()