import socket
import requests
import concurrent.futures
import requests,os,sys, time
xanhnhat = "\033[1;36m"
trang = "\033[1;37m"
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
      \033[1;37mTOOL CHECK PROXY SIÊU VIP
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = = = = = = \n'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
def check_proxy(proxy):
    try:
        socket.setdefaulttimeout(10)
        host, port = proxy.split(':')
        socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, int(port)))
        return True
    except:
        pass
    return False

def remove_dead_proxies(input_file):
    with open(input_file, 'r') as file:
        proxies = file.readlines()

    alive_proxies = []
    proxy_count = len(proxies)  # Số lượng proxy trong danh sách ban đầu
    live_proxy_count = 0  # Số lượng proxy sống đã quét ra
    die_proxy_count = 0  # Số lượng proxy die đã quét ra và bị loại bỏ

    with concurrent.futures.ThreadPoolExecutor() as executor:
        futures = []
        for proxy in proxies:
            future = executor.submit(check_proxy, proxy.strip())
            futures.append((proxy.strip(), future))

        for proxy, future in futures:
            if future.result():
                alive_proxies.append(proxy)
                live_proxy_count += 1
                print(f'\033[1;37mCHECK PROXY \033[1;35m| \033[1;36mTOOL:\033[1;37m{proxy} \033[1;33mTrạng thái: \033[1;32mLive')
            else:
                print(f'\033[1;37mCHECK PROXY \033[1;35m| \033[1;36mTOOL:\033[1;37m{proxy} \033[1;33mTrạng thái: \033[1;31mDie')
                if remove_proxy(proxy):
                    print(f'\033[1;37mXÓA PROXY \033[1;35m| \033[1;36mTOOL:\033[1;37m{proxy} \033[1;33mTrạng thái: \033[1;34mXóa thành công')
                    die_proxy_count += 1
                else:
                    print(f'\033[1;337mXóa PROXY \033[1;35m| \033[1;36mTOOL:\033[1;37m{proxy} \033[1;33mTrạng thái: \033[1;31mXóa không thành công')

    with open(input_file, 'w') as file:
        file.write('\n'.join(alive_proxies))

    print(f'\nCheck thành công {proxy_count} proxy')
    print(f'\033[1;32mProxy Live: {live_proxy_count}')
    print(f'\033[1;31mProxy Die: {die_proxy_count}')
    print(f'\033[1;37mTool Scan được làm bởi ADMIN: PCM TOOL \033[1;31m!!!')

def remove_proxy(proxy):
    try:
        with open(input_file, 'r') as file:
            proxies = file.readlines()

        with open(input_file, 'w') as file:
            for line in proxies:
                if line.strip() != proxy:
                    file.write(line)

        return True
    except:
        return False

# Đường dẫn tới tệp chứa danh sách proxy
#os.system("cls" if os.name == "nt" else "clear"#
input_file = input("\033[1;36mNhập File Proxy Cần Check: \033[1;37m")

# Kiểm tra và xóa proxy không hoạt động, chỉ xóa proxy die khỏi danh sách ban đầu
remove_dead_proxies(input_file)