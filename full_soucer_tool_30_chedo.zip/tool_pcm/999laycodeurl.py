import requests,os,sys,time
import requests
trang = "\033[1;37m"
xanh_la = "\033[0;32m"
xanh_duong = "\033[1;34m"
do = "\033[1;31m"
vang = "\033[1;33m"
tim = "\033[1;35m"
xanhnhat = "\033[0;36m"
lamd = "\033[1;34m"
luc = "\033[1;32m"
pcmcute = "\033[0;37m"
#///////////////
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
        
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝
    
        {luc}TOOL LẤY CODE TỪ LINK
\033[1;35m= = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
link = input(f"\033[0;34mNhập Link Web Chứa Code: {pcmcute}")
print(pcmcute+'='*55)
a = requests.get(link).text
open("pcm.py", "a").write(a)
print(f"{pcmcute}Lấy code thành công và lưu vào file {xanh_la}pcm.py")