import requests,os,sys,time
#import requests
trang = "\033[1;37m"
pcmcute = "\033[0;37m"
xanhnhat = "\033[1;36m"
def banner():
        os.system("cls" if os.name == "nt" else "clear")
        banner =f'''
    {xanhnhat}███╗   ███╗   ████████╗ ██████╗  ██████╗ ██╗     
    {trang}████╗ ████║   ╚══██╔══╝██╔═══██╗██╔═══██╗██║     
    {xanhnhat}██╔████╔██║{xanhnhat}█{trang}█{xanhnhat}█{trang}█{xanhnhat}█╗{xanhnhat}██║   ██║   ██║██║   ██║██║     
    {trang}██║╚██╔╝██║{xanhnhat}╚════╝{trang}██║   ██║   ██║██║   ██║██║     
    {xanhnhat}██║ ╚═╝ ██║      ██║   ╚██████╔╝╚██████╔╝███████╗
    {trang}╚═╝     ╚═╝      ╚═╝    ╚═════╝  ╚═════╝ ╚══════╝

          \033[1;93mTOOL LỌC MAIL BAO MÃ
\033[0;37m= = = = = = = = = = = = = = = = = = = = = = = = = = = = = 
'''
        for i in banner:
          sys.stdout.write(i)
          sys.stdout.flush()
          time.sleep(0.00100)
banner()
def gen(file_luu):
    a = requests.get('https://combolist.org/generate').text
    tach = a.split('<textarea id=combolist spellcheck=false>')[1].split('</textarea>')[0]
    #gene = tach.split('\n')[0]
    print(tach)
    if file_luu is not None:
        open(file_luu, 'a').write(tach)
print('\033[0;37mNhập Số Lượng Ae Nhập 1 = 200 mail Nên Cân Nhắc Nhé')
print(pcmcute+'='*50)
sl = int(input('\033[0;37mNhập Số Lượng: \033[0;33m'))
file_luu = input('\033[0;37mNhập File Lưu Mail \033[0;32m(\033[0;37mfile phải \033[1;97m.txt \033[0;37mNhé\033[0;32m): \033[0;33m')
print(pcmcute+'='*50)
print("\033[0;33mChuẩn Bị Đề 3 Nè\033[0;31m...\033[0;32m")
time.sleep(3)
if file_luu == '':
    file_luu = None
for i in range(sl):
    try:
        gen(file_luu)
    except Exception as e:
        print(str(e))